'use strict';

alert('Labas!');
