# React Tutorial

Learn the fundamentals of React, including simple and class components, state, props, and submitting form data.

### [View the Tutorial](https://www.taniarascia.com/getting-started-with-react/)

## License

The code is open source and available under the [MIT License](LICENSE).

Written by [Tania Rascia](https://www.taniarascia.com).